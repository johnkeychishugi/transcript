-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 02, 2021 at 08:11 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transcript`
--

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'FRESHMAN', '2021-08-28 14:11:01', '2021-08-28 14:11:01'),
(2, 'SOLPHMORE', '2021-08-28 14:11:01', '2021-08-28 14:11:01'),
(5, 'PENULTIMATE', '2021-08-28 14:12:00', '2021-08-28 14:12:00'),
(6, 'GRADUATE', '2021-08-28 14:12:00', '2021-08-28 14:12:00'),
(7, 'FINAL YEAR', '2021-08-28 14:12:00', '2021-08-28 14:12:00');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `department_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `number` int(11) NOT NULL,
  `number_semester_hours` int(11) NOT NULL,
  `level` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `department_id`, `name`, `description`, `number`, `number_semester_hours`, `level`, `created_at`, `updated_at`) VALUES
(4, 2, 'Operation Research', 'Operation Research', 5444, 13, 'Second', '2021-08-29 15:44:19', '2021-08-29 15:44:19'),
(5, 2, 'Project Management', 'Project Management', 45654, 65, 'Project Management', '2021-08-29 15:45:20', '2021-08-29 15:45:20');

-- --------------------------------------------------------

--
-- Table structure for table `courses_sections`
--

CREATE TABLE `courses_sections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `section_id` bigint(20) UNSIGNED NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedAt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `courses_sections`
--

INSERT INTO `courses_sections` (`id`, `course_id`, `section_id`, `createdAt`, `updatedAt`) VALUES
(3, 5, 2, '2021-08-29 15:50:33', '2021-08-29 15:50:33'),
(6, 4, 1, '2021-08-29 15:50:33', '2021-08-29 15:50:33'),
(7, 4, 2, '2021-08-30 20:48:10', '2021-08-30 20:48:10');

-- --------------------------------------------------------

--
-- Table structure for table `degree_programs`
--

CREATE TABLE `degree_programs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `degree_programs`
--

INSERT INTO `degree_programs` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'B.A', '2021-08-28 14:13:44', '2021-08-28 14:13:44'),
(2, 'B.S', '2021-08-28 14:13:44', '2021-08-28 14:13:44'),
(3, 'MBA', '2021-08-28 14:15:39', '2021-08-28 14:15:39'),
(4, 'MSC', '2021-08-28 14:15:39', '2021-08-28 14:15:39'),
(5, 'PHD', '2021-08-28 14:15:39', '2021-08-28 14:15:39');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `office_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `office_id`, `name`, `code`, `created_at`, `updated_at`) VALUES
(2, 1, 'Management information System', 97979, '2021-08-29 15:38:04', '2021-08-29 15:38:04'),
(3, 4, 'Bioinformatic', 12121, '2021-08-29 15:39:14', '2021-08-29 15:39:14'),
(4, 3, 'Computer IT', 4432, '2021-08-29 15:39:14', '2021-08-29 15:39:14');

-- --------------------------------------------------------

--
-- Table structure for table `grade_reports`
--

CREATE TABLE `grade_reports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `section_id` bigint(20) UNSIGNED NOT NULL,
  `letter_grade` text NOT NULL,
  `numeric_grade` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `grade_reports`
--

INSERT INTO `grade_reports` (`id`, `student_id`, `section_id`, `letter_grade`, `numeric_grade`, `created_at`, `updated_at`) VALUES
(3, 6, 1, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Possimus esse, assumenda exercitationem nobis quam laboriosam at! Fugit possimus quod natus enim deserunt mollitia eum qui iure, asperiores alias doloribus dolor?', 'Lorem ipsum dolor sit, amet consec?', '2021-08-29 15:48:20', '2021-08-29 15:48:20'),
(4, 10, 1, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Possimus esse, assumenda exercitationem nobis quam laboriosam at! Fugit possimus quod natus enim deserunt mollitia eum qui iure, asperiores alias doloribus dolor?', 'Lorem ipsum dolor sit, ', '2021-08-29 15:48:20', '2021-08-29 15:48:20'),
(6, 11, 2, 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere quae cum soluta eveniet illum libero? Autem nisi perspiciatis tempora harum. Maxime fuga fugiat id provident ratione expedita impedit aliquid non!Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere quae cum soluta eveniet illum libero? Autem nisi perspiciatis tempora harum. Maxime fuga fugiat id provident ratione expedita impedit aliquid non!', 'Lorem ipsum dolor Lorem ipsum dolor sit amet consectetur  ', '2021-08-30 20:45:45', '2021-08-30 20:45:45');

-- --------------------------------------------------------

--
-- Table structure for table `instructors`
--

CREATE TABLE `instructors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `instructors`
--

INSERT INTO `instructors` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'David kay', '2021-08-29 15:34:24', '2021-08-29 15:34:24'),
(2, 'Philo lover', '2021-08-29 15:34:24', '2021-08-29 15:34:24'),
(3, 'Marco oga', '2021-08-29 15:35:01', '2021-08-29 15:35:01'),
(4, 'Philipos vengas', '2021-08-29 15:35:01', '2021-08-29 15:35:01');

-- --------------------------------------------------------

--
-- Table structure for table `offices`
--

CREATE TABLE `offices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `number` int(11) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `offices`
--

INSERT INTO `offices` (`id`, `number`, `phone_number`, `created_at`, `updated_at`) VALUES
(1, 87878, '09999999', '2021-08-29 15:35:43', '2021-08-29 15:35:43'),
(2, 768767, '0978766666', '2021-08-29 15:35:43', '2021-08-29 15:35:43'),
(3, 87301878, '0381038', '2021-08-29 15:35:57', '2021-08-29 15:35:57'),
(4, 268164, '391389', '2021-08-29 15:35:57', '2021-08-29 15:35:57');

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `instructor_id` bigint(20) UNSIGNED NOT NULL,
  `semester` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `number` int(11) NOT NULL,
  `room_number` int(11) NOT NULL,
  `building` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `instructor_id`, `semester`, `year`, `number`, `room_number`, `building`, `created_at`, `updated_at`) VALUES
(1, 1, 'omega', '2021/2022', 23233, 21, 'EDS', '2021-08-29 15:40:48', '2021-08-29 15:40:48'),
(2, 4, 'Alfa', '2012/2013', 4322, 212, 'CST', '2021-08-29 15:40:48', '2021-08-29 15:40:48');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `class_id` bigint(20) UNSIGNED NOT NULL,
  `degree_program_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `ssn` varchar(100) NOT NULL,
  `number` int(11) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `birthday` date NOT NULL,
  `sex` varchar(10) NOT NULL,
  `major_department` varchar(100) NOT NULL,
  `minor_department` varchar(100) NOT NULL,
  `current_address` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `class_id`, `degree_program_id`, `name`, `ssn`, `number`, `phone_number`, `birthday`, `sex`, `major_department`, `minor_department`, `current_address`, `created_at`, `updated_at`) VALUES
(6, 2, 1, 'John Chishugi', '718757', 434343, '3434', '2021-08-19', 'F', '4', '4', 'Kivu/Goma', '2021-08-28 22:57:02', '2021-08-28 22:57:02'),
(10, 5, 3, 'Samy kamanda', '4454', 1212, '2222212', '2021-08-02', 'M', 'CS', 'CS', '2 JD', '2021-08-29 11:48:47', '2021-08-29 11:48:47'),
(11, 1, 2, 'Samuel Oga', '984982948', 90902, '098988887', '2021-08-03', 'M', 'CS', 'CS', 'CS', '2021-08-30 17:22:26', '2021-08-30 17:22:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `courses_sections`
--
ALTER TABLE `courses_sections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `section_id` (`section_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `degree_programs`
--
ALTER TABLE `degree_programs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `office_id` (`office_id`);

--
-- Indexes for table `grade_reports`
--
ALTER TABLE `grade_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `section_id` (`section_id`);

--
-- Indexes for table `instructors`
--
ALTER TABLE `instructors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offices`
--
ALTER TABLE `offices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `instructor_id` (`instructor_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ssn` (`ssn`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `degree_progrem_id` (`degree_program_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `courses_sections`
--
ALTER TABLE `courses_sections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `degree_programs`
--
ALTER TABLE `degree_programs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `grade_reports`
--
ALTER TABLE `grade_reports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `instructors`
--
ALTER TABLE `instructors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `offices`
--
ALTER TABLE `offices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `courses_sections`
--
ALTER TABLE `courses_sections`
  ADD CONSTRAINT `courses_sections_ibfk_1` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `courses_sections_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`office_id`) REFERENCES `offices` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `grade_reports`
--
ALTER TABLE `grade_reports`
  ADD CONSTRAINT `grade_reports_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `grade_reports_ibfk_2` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sections`
--
ALTER TABLE `sections`
  ADD CONSTRAINT `sections_ibfk_1` FOREIGN KEY (`instructor_id`) REFERENCES `instructors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`degree_program_id`) REFERENCES `degree_programs` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
